
function test(){
	var a = 'a';
	var b = 'b';
	var c = 'c';
	return a+b+c;
}
